# Pasta-Enforcer
A Discord Bot that enforces a pasta nick naming scheme (over 30 different pasta names)

WARNING: I'm not exactly sure if this is in violation of the developer ToS so use at your own risk. Although the nickname change is triggered by a user action so it should be fine.

This bot renames users after typing a message to a random pasta name. By default it changes their pasta name on each message you can stop this by uncommenting the if statement in bot.js
